import React, { useState } from 'react';
import '/Users/tuckersnow/Downloads/PatriotPlayers-main-3/frontend/patriot-players/src/CreatePage.css';
import axios from 'axios';

function CreatePage() {
  const [formData, setFormData] = useState({
    lobbyName: '',
    requestedPlayers: '',
    game: '',
    time: '',
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:3000/create-lobby', formData);
      console.log(response.data);
    } catch (error) {
      console.error('Error submitting form:', error);
    }
  };

  return (
    <div className="create-page">
      <header className="header">
        <nav>
          <a href="/">Home</a>
          <a href="/about">About</a>
        </nav>
        <div>tucker</div>
      </header>

      <div className="form-container">
        <form className="create-form" onSubmit={handleSubmit}>
          <label htmlFor="lobbyName">Lobby Name</label>
          <input type="text" id="lobbyName" name="lobbyName" placeholder="Enter lobby name" onChange={handleChange} />

          <label htmlFor="requestedPlayers">Requested Players</label>
          <input type="number" id="requestedPlayers" name="requestedPlayers" placeholder="Number of players" onChange={handleChange} />

          <label htmlFor="game">Game</label>
          <input type="text" id="game" name="game" placeholder="Enter game name" onChange={handleChange} />

          <label htmlFor="time">Time</label>
          <input type="time" id="time" name="time" onChange={handleChange} />

          <div className="form-actions">
            <button type="submit" className="create-button">Create!</button>
            <button type="button" className="cancel-button">Cancel...</button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default CreatePage;
